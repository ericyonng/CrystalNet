# Basic Usage

@snippet api/bsoncxx/examples/validation/basic_usage.cpp Example

# With Validator

@snippet api/bsoncxx/examples/validation/validator.cpp Example
