# Basic Usage

@snippet api/bsoncxx/examples/decimal128/basic_usage.cpp Example

# From Bytes

@snippet api/bsoncxx/examples/decimal128/from_bytes.cpp Example

# Error Handling

@snippet api/bsoncxx/examples/decimal128/errors.cpp Example
